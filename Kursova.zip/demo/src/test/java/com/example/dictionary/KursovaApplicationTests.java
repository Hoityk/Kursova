package com.example.dictionary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KursovaApplicationTests {

	@Test
	void contextLoads() {
	}

}

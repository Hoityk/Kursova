package com.example.teleprogram.controller;

import com.example.teleprogram.model.Schedule;
import com.example.teleprogram.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/schedules")
public class ScheduleController {

    @Autowired
    private ScheduleService scheduleService;

    @PostMapping
    public Schedule addSchedule(@RequestBody Schedule schedule) {
        return scheduleService.saveSchedule(schedule);
    }

    @GetMapping
    public List<Schedule> getAllSchedules() {
        return scheduleService.getAllSchedules();
    }

    @GetMapping("/by-channel")
    public List<Schedule> getSchedulesByChannel() {
        return scheduleService.getSchedulesByChannel();
    }

    @GetMapping("/sorted")
    public List<Schedule> getSchedulesSortedByTime() {
        return scheduleService.getSchedulesSortedByTime();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Schedule> updateSchedule(@PathVariable Long id, @RequestBody Schedule newSchedule) {
        return scheduleService.getScheduleById(id)
                .map(schedule -> {
                    schedule.setStartTime(newSchedule.getStartTime());
                    schedule.setEndTime(newSchedule.getEndTime());
                    scheduleService.saveSchedule(schedule);
                    return ResponseEntity.ok(schedule);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSchedule(@PathVariable Long id) {
        scheduleService.deleteSchedule(id);
        return ResponseEntity.noContent().build();
    }
}








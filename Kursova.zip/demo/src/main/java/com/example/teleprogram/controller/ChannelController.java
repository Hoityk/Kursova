package com.example.teleprogram.controller;

import com.example.teleprogram.model.Channel;
import com.example.teleprogram.service.ChannelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/channels")
public class ChannelController {

    @Autowired
    private ChannelService channelService;

    @PostMapping
    public Channel addChannel(@RequestBody Channel channel) {
        return channelService.saveChannel(channel);
    }

    @GetMapping
    public List<Channel> getAllChannels() {
        return channelService.getAllChannels();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Channel> updateChannel(@PathVariable Long id, @RequestBody Channel newChannel) {
        return channelService.getChannelById(id)
                .map(channel -> {
                    channel.setName(newChannel.getName());
                    channelService.saveChannel(channel);
                    return ResponseEntity.ok(channel);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteChannel(@PathVariable Long id) {
        channelService.deleteChannel(id);
        return ResponseEntity.noContent().build();
    }
}














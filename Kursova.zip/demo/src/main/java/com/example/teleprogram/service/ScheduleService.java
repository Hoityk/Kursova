package com.example.teleprogram.service;

import com.example.teleprogram.model.Schedule;
import com.example.teleprogram.repository.ScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleService {

    @Autowired
    private ScheduleRepository scheduleRepository;

    public Schedule saveSchedule(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    public List<Schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }

    public List<Schedule> getSchedulesByChannel() {
        return scheduleRepository.findAll(); // Update this logic based on your sorting requirements
    }

    public List<Schedule> getSchedulesSortedByTime() {
        return scheduleRepository.findAll(); // Update this logic based on your sorting requirements
    }

    public Optional<Schedule> getScheduleById(Long id) {
        return scheduleRepository.findById(id);
    }

    public void deleteSchedule(Long id) {
        scheduleRepository.deleteById(id);
    }
}












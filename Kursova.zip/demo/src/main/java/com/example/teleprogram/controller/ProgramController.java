package com.example.teleprogram.controller;

import com.example.teleprogram.model.Program;
import com.example.teleprogram.service.ProgramService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/programs")
public class ProgramController {

    @Autowired
    private ProgramService programService;

    @PostMapping
    public Program addProgram(@RequestBody Program program) {
        return programService.saveProgram(program);
    }

    @GetMapping
    public List<Program> getAllPrograms() {
        return programService.getAllPrograms();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Program> updateProgram(@PathVariable Long id, @RequestBody Program newProgram) {
        return programService.getProgramById(id)
                .map(program -> {
                    program.setName(newProgram.getName());
                    programService.saveProgram(program);
                    return ResponseEntity.ok(program);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProgram(@PathVariable Long id) {
        programService.deleteProgram(id);
        return ResponseEntity.noContent().build();
    }
}












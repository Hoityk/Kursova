function login() {
    const form = document.querySelector('form');
    form.method = 'POST';
    form.action = '/login';
    form.submit();
}

function addChannel() {
    const channelName = document.getElementById('channel').value;
    fetch('/channels', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: channelName })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('channel').value = '';
            alert('Channel added successfully');
        })
        .catch(error => console.error('Error:', error));
}

function addProgram() {
    const programName = document.getElementById('program').value;
    fetch('/programs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: programName })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('program').value = '';
            alert('Program added successfully');
        })
        .catch(error => console.error('Error:', error));
}

function addSchedule() {
    const channelId = document.getElementById('channel-id').value;
    const programId = document.getElementById('program-id').value;
    const startTime = document.getElementById('start-time').value;
    const endTime = document.getElementById('end-time').value;

    fetch('/schedules', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            channel: { id: channelId },
            program: { id: programId },
            startTime: startTime,
            endTime: endTime
        })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('channel-id').value = '';
            document.getElementById('program-id').value = '';
            document.getElementById('start-time').value = '';
            document.getElementById('end-time').value = '';
            alert('Schedule added successfully');
        })
        .catch(error => console.error('Error:', error));
}

function viewChannels() {
    fetch('/channels')
        .then(response => response.json())
        .then(data => {
            const result = document.getElementById('admin-channels-result');
            result.innerHTML = '';
            data.forEach(channel => {
                const li = document.createElement('li');
                li.innerHTML = `ID: ${channel.id}, Name: ${channel.name} 
            <button onclick="editChannel(${channel.id}, '${channel.name}')">Edit</button> 
            <button onclick="deleteChannel(${channel.id})">Delete</button>`;
                result.appendChild(li);
            });
        })
        .catch(error => console.error('Error:', error));
}

function viewPrograms() {
    fetch('/programs')
        .then(response => response.json())
        .then(data => {
            const result = document.getElementById('admin-programs-result');
            result.innerHTML = '';
            data.forEach(program => {
                const li = document.createElement('li');
                li.innerHTML = `ID: ${program.id}, Name: ${program.name} 
            <button onclick="editProgram(${program.id}, '${program.name}')">Edit</button> 
            <button onclick="deleteProgram(${program.id})">Delete</button>`;
                result.appendChild(li);
            });
        })
        .catch(error => console.error('Error:', error));
}

function viewSchedulesAdmin() {
    fetch('/schedules')
        .then(response => response.json())
        .then(data => {
            const result = document.getElementById('admin-schedules-result');
            result.innerHTML = '';
            data.forEach(schedule => {
                const li = document.createElement('li');
                li.innerHTML = `ID: ${schedule.id}, Channel: ${schedule.channel ? schedule.channel.name : 'N/A'}, Program: ${schedule.program ? schedule.program.name : 'N/A'}, Start: ${schedule.startTime}, End: ${schedule.endTime} 
            <button onclick="editSchedule(${schedule.id}, ${schedule.channel ? schedule.channel.id : null}, ${schedule.program ? schedule.program.id : null}, '${schedule.startTime}', '${schedule.endTime}')">Edit</button> 
            <button onclick="deleteSchedule(${schedule.id})">Delete</button>`;
                result.appendChild(li);
            });
        })
        .catch(error => console.error('Error:', error));
}

function viewSchedulesUser() {
    fetch('/schedules')
        .then(response => response.json())
        .then(data => {
            const result = document.getElementById('user-schedules-result');
            result.innerHTML = '';
            data.forEach(schedule => {
                const li = document.createElement('li');
                li.innerHTML = `ID: ${schedule.id}, Channel: ${schedule.channel ? schedule.channel.name : 'N/A'}, Program: ${schedule.program ? schedule.program.name : 'N/A'}, Start: ${schedule.startTime}, End: ${schedule.endTime}`;
                result.appendChild(li);
            });
        })
        .catch(error => console.error('Error:', error));
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('button[onclick="viewSchedulesSorted()"]').addEventListener('click', viewSchedulesSorted);
    document.querySelector('button[onclick="showChannelNameForm()"]').addEventListener('click', showChannelNameForm);
    document.querySelector('button[onclick="viewSchedulesByChannel()"]').addEventListener('click', viewSchedulesByChannel);
});

function showChannelNameForm() {
    document.getElementById('channel-name-form').style.display = 'block';
}

function viewSchedulesByChannel() {
    const channelName = document.getElementById('filter-channel-name').value.toLowerCase();
    fetch('/schedules')
        .then(response => response.json())
        .then(data => {
            const filteredSchedules = data.filter(schedule => schedule.channel.name.toLowerCase() === channelName);

            console.log('Filtered schedules by channel:', filteredSchedules);

            const resultContainer = document.getElementById('admin-schedules-result') || document.getElementById('user-schedules-result');
            resultContainer.innerHTML = '';  // Очищаємо поточний вміст

            filteredSchedules.forEach(schedule => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `ID: ${schedule.id}, Channel: ${schedule.channel.name}, Program: ${schedule.program.name}, Start: ${schedule.startTime}, End: ${schedule.endTime}`;
                resultContainer.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error:', error));
}

function viewSchedulesSorted() {
    fetch('/schedules')
        .then(response => response.json())
        .then(data => {
            // Сортуємо розклади за часом початку
            data.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));

            console.log('Sorted schedules:', data);

            // Виводимо відсортований список розкладів
            const result = document.getElementById('admin-schedules-result') || document.getElementById('user-schedules-result');
            result.innerHTML = '';  // Очищаємо поточний вміст

            data.forEach(schedule => {
                const li = document.createElement('li');
                li.innerHTML = `ID: ${schedule.id}, Channel: ${schedule.channel.name}, Program: ${schedule.program.name}, Start: ${schedule.startTime}, End: ${schedule.endTime}`;
                result.appendChild(li);
            });
        })
        .catch(error => console.error('Error:', error));
}




function editChannel(id, name) {
    const newName = prompt("Enter new name for the channel:", name);
    if (newName != null && newName !== "") {
        fetch(`/channels/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName })
        })
            .then(response => response.json())
            .then(data => {
                alert('Channel updated successfully');
                viewChannels();
            })
            .catch(error => console.error('Error:', error));
    }
}

function editProgram(id, name) {
    const newName = prompt("Enter new name for the program:", name);
    if (newName != null && newName !== "") {
        fetch(`/programs/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName })
        })
            .then(response => response.json())
            .then(data => {
                alert('Program updated successfully');
                viewPrograms();
            })
            .catch(error => console.error('Error:', error));
    }
}

function editSchedule(id, channelId, programId, startTime, endTime) {
    const newChannelId = prompt("Enter new channel ID:", channelId);
    const newProgramId = prompt("Enter new program ID:", programId);
    const newStartTime = prompt("Enter new start time:", startTime);
    const newEndTime = prompt("Enter new end time:", endTime);
    if (newChannelId != null && newProgramId != null && newStartTime != null && newEndTime != null) {
        fetch(`/schedules/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                channel: { id: newChannelId },
                program: { id: newProgramId },
                startTime: newStartTime,
                endTime: newEndTime
            })
        })
            .then(response => response.json())
            .then(data => {
                alert('Schedule updated successfully');
                viewSchedules();
            })
            .catch(error => console.error('Error:', error));
    }
}

function deleteChannel(id) {
    if (confirm("Are you sure you want to delete this channel?")) {
        fetch(`/channels/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert('Channel deleted successfully');
                    viewChannels();
                } else {
                    alert('Failed to delete channel');
                }
            })
            .catch(error => console.error('Error:', error));
    }
}

function deleteProgram(id) {
    if (confirm("Are you sure you want to delete this program?")) {
        fetch(`/programs/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert('Program deleted successfully');
                    viewPrograms();
                } else {
                    alert('Failed to delete program');
                }
            })
            .catch(error => console.error('Error:', error));
    }
}

function deleteSchedule(id) {
    if (confirm("Are you sure you want to delete this schedule?")) {
        fetch(`/schedules/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    alert('Schedule deleted successfully');
                    viewSchedules();
                } else {
                    alert('Failed to delete schedule');
                }
            })
            .catch(error => console.error('Error:', error));
    }
}
